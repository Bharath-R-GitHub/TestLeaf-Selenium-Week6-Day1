package week6.day1.assignment.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = { "src/test/java/week6/day1/assignment/features/CreateLead.feature",
		"src/test/java/week6/day1/assignment/features/EditLead.feature",
		"src/test/java/week6/day1/assignment/features/DeleteLead.feature",
		"src/test/java/week6/day1/assignment/features/DuplicateLead.feature",
		"src/test/java/week6/day1/assignment/features/FindLead.feature" }, glue = "week6/day1/assignment/steps", monochrome = true, publish = true)
public class Runner extends AbstractTestNGCucumberTests {

}

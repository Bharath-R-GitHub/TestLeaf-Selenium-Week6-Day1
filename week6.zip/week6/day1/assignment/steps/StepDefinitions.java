package week6.day1.assignment.steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDefinitions {

	public ChromeDriver driver;
	public String firstLeadID;
	public String changedCompany;
	public String company;

	@Given("Open the Chrome Browser")
	public void openBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
	}

	@Given("Load the Application URL {string}")
	public void loadURL(String url) {
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	@Given("Enter the username as {string}")
	public void enterUserName(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
	}

	@Given("Enter the password as {string}")
	public void enterPassword(String passWord) {
		driver.findElement(By.id("password")).sendKeys(passWord);
	}

	@When("Click on Login Button")
	public void login() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("Validate CRMSFA link")
	public void validatePage() {
		boolean displayed = driver.findElement(By.linkText("CRM/SFA")).isDisplayed();
		if (displayed) {
			System.out.println("Home page is displayed. Validation Success");
		} else {
			System.out.println("Home page is not displayed. Validation Failed");
		}
	}

	@When("Click on CRMSFA Link")
	public void clickCRMLink() {
		driver.findElement(By.linkText("CRM/SFA")).click();
	}

	@Then("Click on Leads Button")
	public void clickLead() {
		driver.findElement(By.linkText("Leads")).click();
	}

	@Given("Click on Create Lead Button")
	public void clickCreateLead() {
		driver.findElement(By.linkText("Create Lead")).click();
	}

	@Given("Fill the details in the form with CompanyName as {string} and Enter FirstName as {string} and Enter LastName as {string}")
	public void createLead_1(String cName, String fName, String lName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
	}

	@Given("Enter FirstNameLocal as {string} and Enter the Department as {string} and Enter the Description as {string}")
	public void createLead_2(String locFName, String dept, String desc) {
		driver.findElement(By.id("createLeadForm_firstNameLocal")).sendKeys(locFName);
		driver.findElement(By.id("createLeadForm_departmentName")).sendKeys(dept);
		driver.findElement(By.id("createLeadForm_description")).sendKeys(desc);
	}

	@Given("Enter the Email as {string} and Enter the mobile number as {string} and Enter StateProvince as {string}")
	public void createLead_3(String email, String phoneNum, String state) {
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);
		driver.findElement(By.xpath("//input[@id='createLeadForm_primaryPhoneNumber']")).sendKeys(phoneNum);
		WebElement ddElement = driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select dd = new Select(ddElement);
		dd.selectByVisibleText(state);
	}

	@When("Click on Submit Button")
	public void submit() {
		driver.findElement(By.name("submitButton")).click();
	}

	@Then("Validate resulting page")
	public void createLeadValidate() {
		String resultingPage = driver.getTitle();
		if (resultingPage.contains("View Lead")) {
			System.out.println("View Lead page is displayed. Validation Successs");
		} else {
			System.out.println("View Lead page is not displayed. Validation Failed");
		}
		driver.close();
	}

	@Given("Enter the Email as {string} and Enter StateProvince as {string}")
	public void EditLead(String email, String state) {
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);
		WebElement ddElement = driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select dd = new Select(ddElement);
		dd.selectByVisibleText(state);
	}

	@Given("Click on Submit Button to Create Lead")
	public void leadSubmit() {
		driver.findElement(By.name("submitButton")).click();
	}

	@Given("Click on Edit Button")
	public void clickEditButton() {
		driver.findElement(By.linkText("Edit")).click();
	}

	@Given("Clear the Description Field and fill ImportantNote Field as {string}")
	public void editField(String note) {
		driver.findElement(By.id("updateLeadForm_description")).clear();
		driver.findElement(By.id("updateLeadForm_importantNote")).sendKeys(note);
	}

	@When("Click on Update Button")
	public void clickUpdateButton() {
		driver.findElement(By.className("smallSubmit")).click();
	}

	@Given("Click on Find Leads Button")
	public void clickFindLead() {
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();
	}

	@Given("Click on phone")
	public void clickPhone() {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
	}

	@Given("Enter phone number as {string}")
	public void getPhoneNumber(String phoneNum) {
		driver.findElement(By.name("phoneNumber")).sendKeys(phoneNum);
	}

	@Given("Click on Find Lead")
	public void findLead() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
	}

	@Given("Capture First resulting Lead")
	public void captureLead() throws InterruptedException {
		firstLeadID = driver.findElement(By.xpath("//div[contains(@class,'x-grid3-col-partyId')]/a[1]")).getText();
		System.out.println("The First Lead ID is " + firstLeadID);
		driver.findElement(By.xpath("//div[contains(@class,'x-grid3-col-partyId')]/a[1]")).click();
	}

	@Given("Click on Delete Lead")
	public void deleteLead() {
		driver.findElement(By.xpath("//a[text()='Delete']")).click();
	}

	@Given("Enter captured Lead")
	public void capturedLead() {
		driver.findElement(By.xpath("//div[@class='x-form-element']/input[@name='id']")).sendKeys(firstLeadID);
	}

	@When("Click on Find Lead Button")
	public void searchLead() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
	}

	@Then("Validate Lead")
	public void validateLead() {
		String verify = driver.findElement(By.xpath("//div[@class='x-paging-info']")).getText();
		if (verify.equals("No records to display")) {
			System.out.println("I confirmed that the Lead ID " + firstLeadID + " has been Deleted Successfully");
		} else {
			System.out.println("The Lead ID " + firstLeadID + " has not Deleted yet");
		}
		driver.close();
	}

	@Given("Click on Duplicate Lead Button")
	public void duplicateLead() {
		driver.findElement(By.linkText("Duplicate Lead")).click();
	}

	@Given("Enter new company as {string} and new name as {string}")
	public void duplicateLeadFields(String newCName, String newFName) {
		driver.findElement(By.id("createLeadForm_companyName")).clear();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(newCName);
		driver.findElement(By.id("createLeadForm_firstName")).clear();
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(newFName);
	}

	@Given("Enter the firstName as {string}")
	public void enterFirstName(String fName) {
		driver.findElement(
				By.xpath("//div[contains(@class,'x-tab-item')]/following-sibling::div/div/input[@name='firstName']"))
				.sendKeys(fName);
	}

	@Given("Change the company name to {string}")
	public void changeCompany(String chgCompany) {
		changedCompany = chgCompany;
		driver.findElement(By.xpath("//input[@id='updateLeadForm_companyName']")).clear();
		driver.findElement(By.xpath("//input[@id='updateLeadForm_companyName']")).sendKeys(chgCompany);
	}

	@Given("Click on Update")
	public void clickUpdate() throws InterruptedException {
		driver.findElement(By.xpath("//input[@value='Update']")).click();
		Thread.sleep(2000);
	}

	@When("Get the company name")
	public void getCmpName() {
		company = driver.findElement(By.id("viewLead_companyName_sp")).getText();
	}

	@Then("Validate company name")
	public void validateCmpName() {
		if (company.contains(changedCompany)) {
			System.out.println("I confirmed that the Changed Company Name Appeared");
		} else {
			System.out.println("The Changed Company Name does not Appeared");
		}
		driver.close();
	}
}
